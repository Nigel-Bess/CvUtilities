//
// Created by steve on 2/25/21.
//

#include "Fulfil.Dispense/commands/post_drop/post_LFR_response.h"
#include <json.hpp>
#include <iostream>

using fulfil::dispense::commands::PostLFRResponse;
using fulfil::utils::Logger;

void PostLFRResponse::encode_payload()
{
  std::shared_ptr<nlohmann::json> result_json = std::make_shared<nlohmann::json>();
  (*result_json)["Error"] = this->success_code;
  (*result_json)["Max_Depth_X"] = this->max_depth_point_X;
  (*result_json)["Max_Depth_Y"] = this->max_depth_point_Y;
  (*result_json)["Max_Z"] = this->max_Z;
  (*result_json)["Items_Dispensed"] = this->items_dispensed;
  (*result_json)["Bag_Full_Percent"] = this->Bag_Full_Percent;
  (*result_json)["Item_On_Target_Percent"] = this->Item_On_Target_Percent;
  (*result_json)["Products_To_Overflow"] = this->Products_To_Overflow;
  (*result_json)["Anomaly_Present"] = this->anomaly_present;
  (*result_json)["Item_On_Ground"] = this->item_on_ground;
  (*result_json)["Floor_Analysis_Confidence_Score"] = this->floor_analysis_confidence_score;

  std::string json_string = result_json->dump();
  Logger::Instance()->Info("Encoding PostLFRResponse as: {}", json_string);
  int json_length = json_string.size();
  const char* json_text = json_string.c_str();
  char* response = new char[json_length + 1];
  memcpy(response, json_text, json_length);
  response[json_length] = 0;
  this->payload = std::make_shared<std::string>(response);
  delete [] response;
}


PostLFRResponse::PostLFRResponse(std::shared_ptr<std::string> command_id, int success_code, std::shared_ptr<fulfil::utils::Point3D> max_Z,
                                 int items_dispensed, int Bag_Full_Percent, int Item_On_Target_Percent, bool anomaly_present, bool item_on_ground, float floor_analysis_confidence_score)
{
  this->command_id = command_id;
  this->success_code = success_code;
  this->max_depth_point_X = std::round(max_Z->x * 1000);
  this->max_depth_point_Y = std::round(max_Z->y * 1000);
  this->max_Z = std::round(max_Z->z * 1000); //conversion from meters to mm for VLSG response
  this->items_dispensed = items_dispensed;
  this->Bag_Full_Percent = Bag_Full_Percent;
  this->Item_On_Target_Percent = Item_On_Target_Percent;
  this->Products_To_Overflow = std::vector<int>();
  this->anomaly_present = anomaly_present;
  this->item_on_ground = item_on_ground;
  this->floor_analysis_confidence_score = floor_analysis_confidence_score;
}

std::shared_ptr<std::string> PostLFRResponse::get_command_id()
{
  return this->command_id;
}

int PostLFRResponse::get_success_code()
{
  return this->success_code;
}

void PostLFRResponse::set_items_dispensed(std::pair<int, int> values)
{
  this->items_dispensed = values.first;
  this->Item_On_Target_Percent = values.second;
}

void PostLFRResponse::set_products_to_overflow(std::vector<int> products)
{
    this->Products_To_Overflow = products;
}

int PostLFRResponse::dispense_payload_size()
{
  if(!(this->payload))
  {
    this->encode_payload();
  }
  return this->payload->length() + 1;
}

std::shared_ptr<std::string> PostLFRResponse::dispense_payload()
{
  if(!(this->payload))
  {
    this->encode_payload();
  }
  return this->payload;
}